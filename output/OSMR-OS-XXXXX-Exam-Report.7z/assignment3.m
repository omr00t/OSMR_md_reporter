// OSMR certification challenge
// Code for assignment 3
